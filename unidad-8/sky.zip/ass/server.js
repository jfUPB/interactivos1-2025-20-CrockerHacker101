const express = require("express");
const http = require("http");
const socketIO = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

// 📂 Servir archivos estáticos desde la carpeta "public"
app.use(express.static(path.join(__dirname, "public")));

// ✅ Rutas para los clientes
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.get("/desktop", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "desktop", "index.html"));
});

app.get("/mobile", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "mobile", "index.html"));
});

// 🧠 Comunicación con clientes mediante Socket.IO
io.on("connection", (socket) => {
  console.log("🟢 Cliente conectado:", socket.id);

  // 📱 Datos desde el móvil → reenviar al escritorio
  socket.on("mobileData", (data) => {
    io.emit("desktopData", data);
  });

  // 💻 Datos desde el escritorio → pueden venir del Micro:bit también
  socket.on("desktopData", (data) => {
    io.emit("desktopData", data);
  });

  // 💥 Explosión manual (desde el móvil o Micro:bit)
  socket.on("explode", () => {
    io.emit("desktopData", { type: "explode" });
  });

  // 🔌 Desconexión
  socket.on("disconnect", () => {
    console.log("🔴 Cliente desconectado:", socket.id);
  });
});

// 🚀 Iniciar el servidor
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`✅ Servidor corriendo en http://localhost:${PORT}`);
});
