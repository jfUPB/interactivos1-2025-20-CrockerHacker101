const socket = io();
const canvas = document.getElementById('canvas');
const input = document.getElementById('ideaText');
let ideaIdCounter = 0;
const ideas = {};

function crearIdea() {
  const text = input.value.trim();
  if (!text) return;
  const id = `idea-${Date.now()}`;
  const x = Math.random() * (canvas.clientWidth - 100);
  const y = Math.random() * (canvas.clientHeight - 50);
  const idea = { id, text, x, y, votos: 0 };
  renderIdea(idea);
  socket.emit('crear_idea', idea);
  input.value = '';
}

function renderIdea(idea) {
  const div = document.createElement('div');
  div.className = 'idea';
  div.id = idea.id;
  div.innerText = idea.text;
  div.style.left = idea.x + 'px';
  div.style.top = idea.y + 'px';
  div.onclick = () => {
    idea.votos += 1;
    div.classList.add('votada');
    socket.emit('votar_idea', idea.id);
  };

  makeDraggable(div, idea);
  canvas.appendChild(div);
  ideas[idea.id] = { element: div, data: idea };
}

function makeDraggable(el, idea) {
  let offsetX, offsetY;

  el.onmousedown = function (e) {
    offsetX = e.clientX - el.offsetLeft;
    offsetY = e.clientY - el.offsetTop;
    document.onmousemove = (e) => {
      el.style.left = e.clientX - offsetX + 'px';
      el.style.top = e.clientY - offsetY + 'px';
    };
    document.onmouseup = () => {
      document.onmousemove = null;
      document.onmouseup = null;
      idea.x = parseInt(el.style.left);
      idea.y = parseInt(el.style.top);
      socket.emit('mover_idea', idea);
    };
  };
}

// Eventos desde el servidor
socket.on('nueva_idea', renderIdea);

socket.on('idea_movida', (idea) => {
  const div = document.getElementById(idea.id);
  if (div) {
    div.style.left = idea.x + 'px';
    div.style.top = idea.y + 'px';
  }
});

socket.on('idea_votada', (id) => {
  const idea = ideas[id];
  if (idea) {
    idea.data.votos += 1;
    idea.element.classList.add('votada');
  }
});
