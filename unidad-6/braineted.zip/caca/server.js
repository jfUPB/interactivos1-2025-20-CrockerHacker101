const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.static('public'));

io.on('connection', (socket) => {
  console.log(' Usuario conectado');

  socket.on('crear_idea', (data) => {
    socket.broadcast.emit('nueva_idea', data);
  });

  socket.on('mover_idea', (data) => {
    socket.broadcast.emit('idea_movida', data);
  });

  socket.on('votar_idea', (ideaId) => {
    socket.broadcast.emit('idea_votada', ideaId);
  });

  socket.on('conectar_ideas', (data) => {
    socket.broadcast.emit('ideas_conectadas', data);
  });

  socket.on('disconnect', () => {
    console.log(' Usuario desconectado');
  });
});

server.listen(3000, () => {
  console.log(' Servidor escuchando en http://localhost:3000');
});
