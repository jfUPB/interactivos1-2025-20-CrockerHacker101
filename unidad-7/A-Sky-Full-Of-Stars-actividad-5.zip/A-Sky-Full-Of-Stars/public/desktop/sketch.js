let socket;
let star;
let stars = [];
let shootingStars = [];
let reactiveStars = [];
let song;
let amplitude;
let fft;
let explode = false;
let regenTimer = 0;
let waveformColor;

function preload() {
  song = loadSound("/assets/sky_full_of_stars.mp3");
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  socket = io();

  // Identifica este cliente como escritorio
  socket.emit("clientType", "desktop");

  song.play();
  song.setVolume(0.8);
  amplitude = new p5.Amplitude();
  fft = new p5.FFT(0.8, 256);
  waveformColor = color(255, 255, 150);

  star = { x: width / 2, y: height / 2, trail: [] };

  for (let i = 0; i < 200; i++) {
    let isReactive = random() > 0.2;
    (isReactive ? reactiveStars : stars).push({
      x: random(width),
      y: random(height),
      size: random(1, 3),
      pulse: random(0.5, 1.5),
    });
  }

  socket.on("desktopData", (data) => {
    if (data.type === "move") {
      star.x = data.x * width;
      star.y = data.y * height;
    } else if (data.type === "explode") {
      explodeStar();
    }
  });
}

function draw() {
  background(10, 15, 40);
  let level = amplitude.getLevel();

  noStroke();
  for (let s of stars) {
    let flicker = sin(frameCount * 0.05 + s.pulse) * 2 + 3;
    fill(255, 255, random(100, 200));
    ellipse(s.x, s.y, s.size * flicker, s.size * flicker);
  }

  for (let s of reactiveStars) {
    let pulse = 2 + level * 100;
    fill(255, 255, random(150, 255));
    ellipse(s.x, s.y, s.size * pulse, s.size * pulse);
  }

  if (random() < 0.01) {
    shootingStars.push({
      x: random(width),
      y: random(height / 2),
      speed: random(10, 20),
      angle: random(TWO_PI),
      life: millis() + 2000,
    });
  }

  drawExplosion();

  star.trail.push({ x: star.x, y: star.y, alpha: 255 });
  if (star.trail.length > 30) star.trail.shift();

  noFill();
  stroke(255, 255, 120);
  for (let i = 0; i < star.trail.length; i++) {
    let t = star.trail[i];
    stroke(255, 255, 120, t.alpha);
    ellipse(t.x, t.y, 20);
    t.alpha -= 8;
  }

  if (!explode) {
    fill(255, 255, 100);
    noStroke();
    ellipse(star.x, star.y, 40, 40);
  }

  let waveform = fft.waveform();
  noFill();
  stroke(waveformColor);
  strokeWeight(2);
  beginShape();
  for (let i = 0; i < waveform.length; i++) {
    let x = map(i, 0, waveform.length, 0, width);
    let y = map(waveform[i], -1, 1, height - 200, height - 100);
    vertex(x, y);
  }
  endShape();

  if (explode && millis() - regenTimer > 5000) {
    explode = false;
  }
}

function explodeStar() {
  explode = true;
  regenTimer = millis();

  for (let i = 0; i < 50; i++) {
    shootingStars.push({
      x: star.x,
      y: star.y,
      speed: random(5, 15),
      angle: random(TWO_PI),
      life: millis() + 2000,
    });
  }
}

function drawExplosion() {
  for (let i = shootingStars.length - 1; i >= 0; i--) {
    let s = shootingStars[i];

    if (millis() > s.life) {
      shootingStars.splice(i, 1);
      continue;
    }

    s.x += cos(s.angle) * s.speed;
    s.y += sin(s.angle) * s.speed;
    s.speed *= 0.95;

    let alpha = map(s.life - millis(), 0, 2000, 0, 255);
    fill(255, 255, 180, alpha);
    noStroke();
    ellipse(s.x, s.y, 5);
  }
}