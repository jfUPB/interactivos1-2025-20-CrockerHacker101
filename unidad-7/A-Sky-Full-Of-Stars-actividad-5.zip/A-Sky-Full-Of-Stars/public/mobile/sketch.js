let socket;
let star;
let explosionButton;

function setup() {
  createCanvas(windowWidth, windowHeight);
  socket = io();
  socket.emit("clientType", "mobile");

  star = { x: width / 2, y: height / 2 };

  explosionButton = createButton('💥 Explosión');
  explosionButton.position(width / 2 - 60, height - 80);
  explosionButton.size(120, 50);
  explosionButton.style('font-size', '20px');
  explosionButton.mousePressed(triggerExplosion);
}

function draw() {
  background(10, 10, 40);
  fill(255, 255, 100);
  noStroke();
  ellipse(star.x, star.y, 30, 30);

if (touches.length > 0) {
  star.x = lerp(star.x, touches[0].x, 0.3);
  star.y = lerp(star.y, touches[0].y, 0.3);

  socket.emit("mobileData", {
    type: "move",
    x: star.x / width,
    y: star.y / height
  });
 }
}

function triggerExplosion() {
  socket.emit("mobileData", { type: "explode" });
}
