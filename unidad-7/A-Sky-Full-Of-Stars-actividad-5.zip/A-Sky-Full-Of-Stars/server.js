// server.js
const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

// 📂 Servir archivos estáticos desde la carpeta "public"
app.use(express.static(path.join(__dirname, 'public')));

// ✅ Rutas para los clientes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/desktop', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'desktop', 'index.html'));
});

app.get('/mobile', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'mobile', 'index.html'));
});

// 🧠 Comunicación Socket.IO
io.on('connection', (socket) => {
  console.log('🟢 Cliente conectado:', socket.id);

  // 📱 Recibir datos del móvil
  socket.on('mobileData', (data) => {
    // Reenviar los datos solo a los clientes del escritorio
    io.emit('desktopData', data);
  });

  // 📱 Evento específico para explosión
  socket.on('explode', () => {
    io.emit('desktopData', { type: 'explode' });
  });

  socket.on('disconnect', () => {
    console.log('🔴 Cliente desconectado:', socket.id);
  });
});

// 🚀 Iniciar el servidor
const port = process.env.PORT || 3000;
server.listen(port, () => {
  console.log(`✅ Servidor corriendo en http://localhost:${port}`);
});
